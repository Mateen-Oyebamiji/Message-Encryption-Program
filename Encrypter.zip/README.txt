
Program author: Bola-Oyebamiji Abdul-Mateen
purpose: decryption and encryption of strings using a key
source files: Assignment1.c

compilation command: gcc -o a1 assignment1.c
                     ./a
               

launching and operating instructions:
					choose an option to decrypt or encrypt a string by inputting the appropriate number
					enter a key(between numbers 1 to 15)
					enter the string to be encoded or decoded
					
